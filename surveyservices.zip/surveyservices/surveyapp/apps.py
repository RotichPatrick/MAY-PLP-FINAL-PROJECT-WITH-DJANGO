from django.apps import AppConfig


class SurveyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'surveyapp'
